# LambdaTest Screenshots
Generate Screenshots on different mobile and desktop browsers from Google Chrome.
