$(function () {
  $("#zoom_img2").show();
  $("#zoom_img").on("load", function () {
    $("#zoom_img2").hide();
  });
  $(".navbar-left__toggle> a").click(function (e) {
    e.preventDefault();
    $(this).parents("nav").toggleClass("navbar-expand");
  });

  $(".navbar-left .dropdown-toggle").click(function (e) {
    e.preventDefault();
    $this = $(this).next();
    $(".side-menu>li").removeClass("active");
    $(this).parent().addClass("active");
    $(".side-menu__dropdown-menu").not($this).slideUp();
    $(this).next().slideToggle();
  });
});
new Vue({
  el: "#ltScrTestlogApp",
  data: {
    user_name: "",
    _pagesUrl: {},
    is_loader_active: false,
    logs: [],
    total_logs: 0,
    limit: 50,
    offset: 0,
    status: "all",
    search_test: "",
    test_log: {},
  },
  created() {
    this.getTestLogs();
    this._getPagesUrl();
  },
  methods: {
    getTestLogs: function () {
      this.is_loader_active = true;
      chrome.storage.sync.get(
        ["lt_scr_access_token", "lt_user_name"],
        (items) => {
          if (!chrome.runtime.error) {
            if (items.lt_user_name) {
              this.user_name = items.lt_user_name;
            }
            if (items.lt_scr_access_token) {
              axios
                .get(
                  `${lt_falcon_url}/user-tests/screenshot?limit=${this.limit}&offset=${this.offset}`,
                  {
                    headers: {
                      "Content-type": "application/json",
                      accessToken: items.lt_scr_access_token,
                      username: this.user_name,
                    },
                  }
                )
                .then(
                  function (response) {
                    this.total_logs = response.data.tests.length;
                    this.logs = response.data.tests.filter(function (log) {
                      return log.test_type_id === "Screenshot";
                    });
                    this.is_loader_active = false;
                  }.bind(this)
                )
                .catch(
                  function (error) {
                    this.is_loader_active = false;
                    if (error.response && error.response.status === 401) {
                      alert(
                        `Please activate LambdaTest Screenshot plugin by entering Access Token. Click Here to know how`
                      );
                    } else if (
                      error.response &&
                      error.response.status === 402
                    ) {
                      alert(
                        "Uh Ohhhh....!!! Looks like you have exhausted your free screenshot sessions for this month. Upgrade your plan to get Unlimited Screenshots"
                      );
                    } else {
                      alert("Please contact to support");
                    }
                    window.location.href = `${chrome.runtime.getURL(
                      "welcome.html"
                    )}`;
                  }.bind(this)
                );
            } else {
              this.is_loader_active = true;
              window.location.href = `${chrome.runtime.getURL("welcome.html")}`;
            }
          } else {
            this.is_loader_active = true;
            window.location.href = `${chrome.runtime.getURL("welcome.html")}`;
          }
        }
      );
    },
    getTestlLogDetail: function (log) {
      chrome.tabs.create({
        url: `${chrome.runtime.getURL("thumbnail.html")}?test_id=${
          log.test_id
        }&url=${log.test_url}`,
      });
    },
    pagination: function (_offset) {
      this.offset = this.offset + _offset * this.limit;
      this.getTestLogs();
    },
    getStatus: function () {
      console.log(this.status);
      if (this.status === "all" || this.status === "") {
        this.getTestLogs();
      } else {
        this.getTestLogs();
        setTimeout(() => {
          this.logs = this.logs.filter((log) => {
            return log.completed_ind === this.status;
          });
        }, 5000);
      }
    },
    searchTest: function () {
      this.getTestLogs();
      setTimeout(() => {
        if (this.search_test) {
          let _search_test = this.search_test.toLowerCase();
          this.logs = this.logs.filter(function (log) {
            return (
              log.test_id.toLowerCase().includes(`${_search_test}`) ||
              log.test_url.toLowerCase().includes(`${_search_test}`)
            );
          });
        }
      }, 5000);
    },
    _getPagesUrl: function () {
      this._pagesUrl = {
        setting: chrome.runtime.getURL("welcome.html"),
        test_log: chrome.runtime.getURL("test_log.html"),
        screenshot: chrome.runtime.getURL("screenshot.html"),
      };
    },
    _hrefChange: function (_location) {
      window.location.href = _location;
    },
    logout: function () {
      chrome.storage.sync.remove([
        "email",
        "token",
        "lt_user_name",
        "lt_scr_access_token",
        "lt_scr_organization_id",
        "is_verified",
        "myDefaultConf",
      ]);
      window.location.href = chrome.runtime.getURL("welcome.html");
    },
  },
});
