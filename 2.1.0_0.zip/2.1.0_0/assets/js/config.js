var lt_falcon_url = "https://manual-api.lambdatest.com",
  lt_lums_url = "https://accounts.lambdatest.com",
  lt_download_all_url = "https://app.lambdatest.com";

