$(document).ready(function () {
  if ($(`input[name="email"]`).val() && $(`input[name="token"]`).val()) {
    $(`._activate`).addClass("display_none");
  } else {
    $(`.edited`).addClass("display_none");
  }

  $(".navbar-left__toggle> a").click(function (e) {
    e.preventDefault();
    $(this).parents("nav").toggleClass("navbar-expand");
  });

  $(".navbar-left .dropdown-toggle").click(function (e) {
    e.preventDefault();
    $this = $(this).next();
    $(".side-menu>li").removeClass("active");
    $(this).parent().addClass("active");
    $(".side-menu__dropdown-menu").not($this).slideUp();
    $(this).next().slideToggle();
  });
});

document.body.onload = function () {
  chrome.storage.sync.get(["email", "token", "lt_user_name"], function (items) {
    if (!chrome.runtime.error) {
      if (items.email) {
        $('input[name="email"]').val(`${items.email}`);
      }
      if (items.token) {
        $('input[name="token"]').val(`${items.token}`);
      }
    }
  });
};

new Vue({
  el: "#homeApp",
  data: {
    user_name: "",
    pagesUrl: {},
    is_loading_active: false,
    email: "",
    token: "",
    verified: true,
    is_verified: false,
    subscriptionDetails: {},
    details: {},
  },
  created() {
    this.getUserDetails();
    this.getPagesUrl();
  },
  methods: {
    onkeyUp: function () {
      this.email = $('input[name="email"]').val();
      this.token = $('input[name="token"]').val();
      chrome.storage.sync.set({
        email: this.email,
        token: this.token,
      });
    },
    activateNow: function () {
      this.email = $('input[name="email"]').val();
      this.token = $('input[name="token"]').val();
      if (this.validEmail(this.email) && this.token && this.token.length > 0) {
        this.getTokenOnHomePgae();
      }
    },
    validEmail: function (email) {
      let regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return regex.test(email);
    },
    getUserDetails: function () {
      chrome.storage.sync.get(["email", "token"], (items) => {
        if (!chrome.runtime.error) {
          this.email = items.email;
          this.token = items.token;
          if (
            this.validEmail(this.email) &&
            this.token &&
            this.token.length > 0
          ) {
            this.getTokenOnHomePgae();
          } else {
            this.verified = false;
          }
        }
      });
    },
    getUserSubscriptionDetails: function () {
      if (this.email && this.token && this.verified === true) {
        chrome.storage.sync.get(["lt_scr_access_token"], (items) => {
          if (!chrome.runtime.error) {
            this.subscriptionDetails = this.details;
            this.is_loading_active = false;
          } else {
            this.is_loading_active = false;
          }
        });
      } else {
        this.is_loading_active = false;
      }
    },
    editForm: function () {
      $(`._activate`).removeClass(`display_none`);
      $(`.edited`).addClass(`display_none`);
      $(`button._activate`).text("Update");
    },
    getTokenOnHomePgae: function () {
      this.is_loading_active = true;
      axios
        .post(`${lt_lums_url}/api/user/token/auth`, {
          email: this.email,
          token: this.token,
        })
        .then(
          function (response) {
            let authData = response.data;
            let config = response.config;

            if (response.status === 200) {
              configData = JSON.parse(config.data);
              this.verified = true;
              $(`#verified`).css("color", "green").text(`Verified`);
              this.user_name = authData.username;
              this.details = authData.organization;
              chrome.storage.sync.set(
                {
                  lt_scr_access_token: configData.token,
                  lt_scr_organization_id: authData.organization.id,
                  lt_user_name: this.user_name,
                  is_verified: true,
                },
                () => {
                  chrome.storage.sync.get(["myDefaultConf"], (items) => {
                    if (!chrome.runtime.error) {
                      if (items.myDefaultConf) {
                        let myDefaultConf = JSON.parse(items.myDefaultConf);
                        this.removeLocalStorageKeys(["myDefaultConf"]);
                        this._sendScreenshot(
                          configData.token,
                          authData.organization.id,
                          myDefaultConf
                        );
                      }
                    }
                    this.getUserSubscriptionDetails();
                  });
                }
              );
            } else {
              this.removeLocalStorageKeys([
                "lt_scr_access_token",
                "lt_scr_organization_id",
                "is_verified",
              ]);
              this.is_loading_active = false;
            }
          }.bind(this)
        )
        .catch(
          function (error) {
            this.removeLocalStorageKeys([
              "lt_scr_access_token",
              "lt_scr_organization_id",
              "is_verified",
            ]);
            this.is_loading_active = false;
            this.verified = false;
            $(`#verified`).css("color", "red").text(`UnVerified`);
            $(`._activate`).removeClass(`display_none`);
            $(`.edited`).addClass(`display_none`);
            $(`button._activate`).text("Update");
          }.bind(this)
        );
    },
    removeLocalStorageKeys: function (keys) {
      chrome.storage.sync.remove(keys);
    },
    _sendScreenshot: function (accessToken, org_id, myDefaultConf) {
      if (org_id != null) {
        myDefaultConf.org_id = org_id;
        myDefaultConf.configs.forEach((element) => {
          delete element.manufacturer_id;
        });
        axios
          .post(`${lt_falcon_url}/tests`, myDefaultConf, {
            headers: {
              "Content-type": "application/json",
              accessToken: `${accessToken}`,
              username: this.user_name,
            },
          })
          .then(
            function (response) {
              let test_id = response.data.test_id;
              if (test_id) {
                this.is_loading_active = false;
                chrome.tabs.create({
                  url: `${chrome.runtime.getURL(
                    "thumbnail.html"
                  )}?test_id=${test_id}&url=${myDefaultConf.url}`,
                });
              }
            }.bind(this)
          )
          .catch(
            function (error) {
              this.is_loading_active = false;
            }.bind(this)
          );
      } else {
        this.is_loading_active = true;
      }
    },
    getPagesUrl: function () {
      this.pagesUrl = {
        setting: chrome.runtime.getURL("welcome.html"),
        test_log: chrome.runtime.getURL("test_log.html"),
        screenshot: chrome.runtime.getURL("screenshot.html"),
      };
    },
    hrefChange: function (_location) {
      window.location.href = _location;
    },
    logout: function () {
      chrome.storage.sync.remove([
        "email",
        "token",
        "lt_user_name",
        "lt_scr_access_token",
        "lt_scr_organization_id",
        "is_verified",
        "myDefaultConf",
      ]);
      window.location.href = chrome.runtime.getURL("welcome.html");
    },
  },
});
