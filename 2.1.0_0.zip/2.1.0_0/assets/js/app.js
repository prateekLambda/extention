$(document).ready(function () {
  try {
    chrome.tabs.getSelected(null, (tab) => {
      const l = tab.url;
      if (l.indexOf(".lambdatest.com") > -1) {
        let headers = {
          "Content-type": "application/json",
          Accept: "application/json",
          "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
        };
        if (l.indexOf("accounts.lambdatest.com") == -1) {
          let ltAccessToken = `${getToken(`accessToken`)}`;
          delete headers["X-CSRF-TOKEN"];
          headers = {
            Authorization: `Bearer ${ltAccessToken}`,
          };
        }
        console.log(lt_lums_url, headers)
        fetchToken(lt_lums_url, headers);
      }
    });
  } catch (error) {}
});

function fetchToken(lt_lums_url, headers) {
  axios
    .get(`${lt_lums_url}/api/user`, { headers })
    .then(
      function (response) {
        getBearerToken(response.data);
      }.bind(this)
    )
    .catch(
      function (error) {
        console.log("fetchToken error", error);
      }.bind(this)
    );
}

function getBearerToken(userData) {
  axios
    .post(`${lt_lums_url}/api/user/token/auth`, {
      email: userData.email,
      token: userData.api_token,
    })
    .then(
      function (response) {
        if (response.status === 200) {
          const _authData = response.data;
          const authData = {
            email: _authData.email,
            token: _authData.token,
            lt_user_name: _authData.username,
            lt_scr_access_token: _authData.token,
            lt_scr_organization_id: _authData.organization.id,
            is_verified: true,
          };
          chrome.storage.sync.set(authData, () => {
            console.log(`Storage Updated Successfully`);
          });
        }
      }.bind(this)
    )
    .catch(
      function (error) {
        console.log("getBearerToken error", error);
      }.bind(this)
    );
}
function getToken(name) {
  let value = "; " + document.cookie;
  let parts = value.split("; " + name + "=");
  if (parts.length == 2) return parts.pop().split(";").shift();
}
