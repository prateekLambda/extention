$(function () {
  $("#zoom_img2").show();
  $("#zoom_img").on("load", function () {
    $("#zoom_img2").hide();
  });
  $(".navbar-left__toggle> a").click(function (e) {
    e.preventDefault();
    $(this).parents("nav").toggleClass("navbar-expand");
  });

  $(".navbar-left .dropdown-toggle").click(function (e) {
    e.preventDefault();
    $this = $(this).next();
    $(".side-menu>li").removeClass("active");
    $(this).parent().addClass("active");
    $(".side-menu__dropdown-menu").not($this).slideUp();
    $(this).next().slideToggle();
  });
});
new Vue({
  el: "#ltScrThumbnailApp",
  data: {
    tPagesUrl: {},
    user_name: "",
    is_loader_active: false,
    devices: [],
    metadata: {},
    width: 0,
    height: 0,
    logs: [],
    total_logs: 0,
    limit: 50,
    offset: 0,
    status: "all",
    search_test: "",
    screenshot_counter: 0,
    pingInterval: "",
    screeshot_url: "",
    test_log: {},
    response_json: {},
    slider_images: [],
    img_slider_is_active: false,
    zoom: "100%",
    current_img: {},
    changeVal: "",
  },
  created() {
    chrome.storage.sync.get(["is_verified", "lt_user_name"], (items) => {
      if (!chrome.runtime.error) {
        if (!items.is_verified) {
          window.location.href = chrome.runtime.getURL("welcome.html");
        }
        if (items.lt_user_name) {
          this.user_name = items.lt_user_name;
        }
      }
    });
    this.getDevices();
    this.getMetaData();
    this.tGetPagesUrl();
    chrome.storage.sync.get(
      ["lt_scr_access_token", "is_verified", "lt_user_name"],
      (items) => {
        if (!chrome.runtime.error) {
          if (items.lt_scr_access_token) {
            this.is_loader_active = true;

            const currentTabUrl = new URL(window.location.href);
            const params = new URLSearchParams(currentTabUrl.search);
            this.screeshot_url = params.get("url");

            this.getScreenshotOfTestId(
              items.lt_scr_access_token,
              params.get("test_id")
            );
          }
          if (!items.is_verified) {
            window.location.href = chrome.runtime.getURL("welcome.html");
          }
          if (items.lt_user_name) {
            this.user_name = items.lt_user_name;
          }
        }
      }
    );
  },
  methods: {
    getDevices: function () {
      axios
        .get(`./assets/launchers/responsive.json`)
        .then(
          function (response) {
            this.devices = response.data;
          }.bind(this)
        )
        .catch(
          function (error) {
            // console.log(`${error.message}`);
          }.bind(this)
        );
    },
    getMetaData: function () {
      axios
        .get(`./assets/launchers/device-meta.json`)
        .then(
          function (response) {
            this.metadata = response.data;
          }.bind(this)
        )
        .catch(
          function (error) {
            // console.log(`${error.message}`);
          }.bind(this)
        );
    },
    logSliderImg: function () {
      let deviceIndex = this.test_log.activities.findIndex((device) => {
        return device.activity_id === this.logVal;
      });
      if (deviceIndex > -1) {
        this.currentImg = this.test_log.activities[
          deviceIndex
        ].screenshots[0].screenshot_url;
      }
    },
    zoomChange: function () {
      $(`.log_img`).css("zoom", this.zoomVal);
    },
    getScreenshotOfTestId: function (lt_scr_access_token, lt_scr_test_id) {
      this.screenshot_counter = 0;
      this.pingInterval = setInterval(() => {
        this.getScreenshots(lt_scr_access_token, lt_scr_test_id);
      }, 4000);

      // Clear Interval After 10 minute.
      setInterval(() => {
        this.clearScreenshotInterval();
      }, 600000);
    },
    getScreenshots: function (lt_scr_access_token, lt_scr_test_id) {
      if (this.screenshot_counter >= 36) {
        this.clearScreenshotInterval();
      }
      this.screenshot_counter++;

      axios
        .get(`${lt_falcon_url}/tests/${lt_scr_test_id}/screenshots`, {
          headers: {
            "Content-type": "application/json",
            accessToken: lt_scr_access_token,
            username: this.user_name,
          },
        })
        .then(
          function (response) {
            let json = response.data;
            if (json && json.completed_ind === "completed") {
              this.clearScreenshotInterval();
            }
            if (json && json.output) {
              this.response_json = json;
              this.is_loader_active = false;
              this.setImageSliderData(this.response_json);
            }
          }.bind(this)
        )
        .catch(
          function (error) {
            this.is_loader_active = false;
            if (error.response && error.response.status === 401) {
              this.clearScreenshotInterval();
              alert(
                `Please activate LambdaTest Screenshot plugin by entering Access Token. Click Here to know how`
              );
            } else if (error.response && error.response.status === 404) {
              this.clearScreenshotInterval();
              alert(`No Record`);
            }
          }.bind(this)
        );
    },
    clearScreenshotInterval: function () {
      if (this.pingInterval) clearInterval(this.pingInterval);
    },
    setImageSliderData: function (response_json) {
      if (Object.keys(response_json.output.desktop).length > 0) {
        for (let key in response_json.output.desktop) {
          response_json.output.desktop[key].forEach((element) => {
            let deviceIndex = this.slider_images.findIndex((device) => {
              return device.activity_id === element.activity_id;
            });
            if (deviceIndex > -1) {
              this.slider_images[deviceIndex] = {
                type: "desktop",
                resolution_id: element.resolution_id,
                activity_id: element.activity_id,
                browser_version:
                  response_json.browsers[element.browser_id].name +
                  " " +
                  response_json.browser_versions[element.browser_version_id]
                    .version_no +
                  " " +
                  response_json.os_versions[element.os_version_id].name,
                screenshot_url:
                  element.screenshots.length > 0
                    ? element.screenshots[0].screenshot_url
                    : "",
                screenshot_img_loader:
                  element.screenshots.length > 0 ? "" : "screenshot_img_loader",
              };
            } else {
              this.slider_images.push({
                type: "desktop",
                resolution_id: element.resolution_id,
                activity_id: element.activity_id,
                browser_version:
                  response_json.browsers[element.browser_id].name +
                  " " +
                  response_json.browser_versions[element.browser_version_id]
                    .version_no +
                  " " +
                  response_json.os_versions[element.os_version_id].name,
                screenshot_url:
                  element.screenshots.length > 0
                    ? element.screenshots[0].screenshot_url
                    : "",
                screenshot_img_loader:
                  element.screenshots.length > 0 ? "" : "screenshot_img_loader",
              });
            }
          });
        }
      }

      if (response_json.output.ios.length > 0) {
        response_json.output.ios.forEach((element) => {
          let deviceIndex = this.slider_images.findIndex((device) => {
            return device.activity_id === element.activity_id;
          });
          if (deviceIndex > -1) {
            this.slider_images[deviceIndex] = {
              type: "ios",
              device_id: element.device_id,
              resolution_id: element.resolution_id,
              activity_id: element.activity_id,
              browser_version:
                response_json.os_versions[element.os_version_id].name +
                " " +
                response_json.devices[element.device_id].name,
              screenshot_url:
                element.screenshots.length > 0
                  ? element.screenshots[0].screenshot_url
                  : "",
              screenshot_img_loader:
                element.screenshots.length > 0 ? "" : "screenshot_img_loader",
            };
          } else {
            this.slider_images.push({
              type: "ios",
              device_id: element.device_id,
              resolution_id: element.resolution_id,
              activity_id: element.activity_id,
              browser_version:
                response_json.os_versions[element.os_version_id].name +
                " " +
                response_json.devices[element.device_id].name,
              screenshot_url:
                element.screenshots.length > 0
                  ? element.screenshots[0].screenshot_url
                  : "",
              screenshot_img_loader:
                element.screenshots.length > 0 ? "" : "screenshot_img_loader",
            });
          }
        });
      }

      if (response_json.output.android.length > 0) {
        response_json.output.android.forEach((element) => {
          let deviceIndex = this.slider_images.findIndex((device) => {
            return device.activity_id === element.activity_id;
          });
          if (deviceIndex > -1) {
            this.slider_images[deviceIndex] = {
              type: "android",
              device_id: element.device_id,
              resolution_id: element.resolution_id,
              activity_id: element.activity_id,
              browser_version:
                response_json.os_versions[element.os_version_id].name +
                " " +
                response_json.devices[element.device_id].name,
              screenshot_url:
                element.screenshots.length > 0
                  ? element.screenshots[0].screenshot_url
                  : "",
              screenshot_img_loader:
                element.screenshots.length > 0 ? "" : "screenshot_img_loader",
            };
          } else {
            this.slider_images.push({
              type: "android",
              device_id: element.device_id,
              activity_id: element.activity_id,
              resolution_id: element.resolution_id,
              browser_version:
                response_json.os_versions[element.os_version_id].name +
                " " +
                response_json.devices[element.device_id].name,
              screenshot_url:
                element.screenshots.length > 0
                  ? element.screenshots[0].screenshot_url
                  : "",
              screenshot_img_loader:
                element.screenshots.length > 0 ? "" : "screenshot_img_loader",
            });
          }
        });
      }
    },
    startSliderImg: function (activity_id, img_urls) {
      if (img_urls) {
        this.img_slider_is_active = true;
        if (this.slider_images.length > 0) {
          let currIndex = this.slider_images.findIndex((device) => {
            return device.activity_id === activity_id;
          });
          if (currIndex > -1) {
            this.current_img = this.slider_images[currIndex];
          } else {
            this.current_img = this.slider_images[0];
          }
          if (this.current_img.type != "desktop") {
            this.width =
              this.response_json.resolutions[this.current_img.resolution_id]
                .width + "px";
            this.height =
              this.response_json.resolutions[this.current_img.resolution_id]
                .height + "px";
          } else {
            this.width = "100%";
            this.height = "100%";
          }
          this.changeMonitorSize(13.3);
          this.changeVal = this.current_img.activity_id;
          if (this.current_img.screenshot_img_loader) {
            $(`#zoom_img`).addClass(
              `${this.current_img.screenshot_img_loader}`
            );
          }

          $(`._thumbnails_container_`).addClass("display_none");
          $(`.slider_img_container`).removeClass("display_none");
        }
      } else {
        alert(`Please wait while image is loading..`);
      }
    },
    onChangeImg: function () {
      $("#zoom_img2").show();
      let deviceIndex = this.slider_images.findIndex((device) => {
        return device.activity_id === this.changeVal;
      });
      if (deviceIndex > -1) {
        this.current_img = this.slider_images[deviceIndex];
        if (this.current_img.type != "desktop") {
          this.width =
            this.response_json.resolutions[this.current_img.resolution_id]
              .width + "px";
          this.height =
            this.response_json.resolutions[this.current_img.resolution_id]
              .height + "px";
        } else {
          this.width = "100%";
          this.height = "100%";
          $(`#zoom_img`).css("width", this.zoom);
        }
        if (this.current_img.screenshot_url.includes(`loading_img`)) {
          $(`#zoom_img`).addClass(`screenshot_img_loader`);
        } else {
          $(`#zoom_img`).removeClass(`screenshot_img_loader`);
        }
        this.changeMonitorSize(13.3);
      }
    },
    onZoom: function () {
      $(`#zoom_img_container`).css("zoom", this.zoom);
      if (this.current_img.type === "desktop") {
        $(`#zoom_img`).css("width", this.zoom);
      } else {
        $(`#zoom_img`).css("width", this.width - 10);
      }
    },
    imageLoadingComplate: function () {
      $("#zoom_img2").hide();
    },
    changeMonitorSize: function (size) {
      if (this.current_img.type !== "desktop") {
        const uw = window.screen.width;
        const uh = window.screen.height;
        let dh = this.devices[0].h;
        let dp = this.devices[0].ppi;

        let deviceIndex = this.devices.findIndex((device) => {
          return device.device_id === this.current_img.device_id;
        });

        if (deviceIndex > -1) {
          dh = this.devices[deviceIndex].h;
          dp = this.devices[deviceIndex].ppi;
        }

        const f2 = dh / dp;
        const w =
          (uw /
            ((parseFloat(size) * uw) /
              uh /
              Math.sqrt(1 + Math.pow(uw / uh, 2)))) *
          f2;
        this.width = w;
        $("#zoom_img_container").width(w);
        $("#zoom_img").width(w - 10);
      }
    },
    backOnThumbnail: function () {
      location.reload(true);
    },
    downloadAll: function (test_id) {
      return `${lt_download_all_url}/zipper/${test_id}`;
    },
    tGetPagesUrl: function () {
      this.tPagesUrl = {
        setting: chrome.runtime.getURL("welcome.html"),
        screenshot: chrome.runtime.getURL("screenshot.html"),
        test_log: chrome.runtime.getURL("test_log.html"),
      };
    },
    tHrefChange: function (_location) {
      window.location.href = _location;
    },
    logout: function () {
      chrome.storage.sync.remove([
        "email",
        "token",
        "lt_user_name",
        "lt_scr_access_token",
        "lt_scr_organization_id",
        "is_verified",
        "myDefaultConf",
      ]);
      window.location.href = chrome.runtime.getURL("welcome.html");
    },
    gotoScreenShot: function () {
      window.location.href = chrome.runtime.getURL("screenshot.html");
    },
  },
});
