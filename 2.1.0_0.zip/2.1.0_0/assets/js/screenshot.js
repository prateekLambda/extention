$(document).ready(function () {
  $("#preference_setting").click(function () {
    $(".setting-price").toggle("up");
  });
  $(".navbar-left__toggle> a").click(function (e) {
    e.preventDefault();
    $(this).parents("nav").toggleClass("navbar-expand");
  });

  $(".navbar-left .dropdown-toggle").click(function (e) {
    e.preventDefault();
    $this = $(this).next();
    $(".side-menu>li").removeClass("active");
    $(this).parent().addClass("active");
    $(".side-menu__dropdown-menu").not($this).slideUp();
    $(this).next().slideToggle();
  });
});
new Vue({
  el: "#screenshotApp",
  data: {
    sPagesUrl: {},
    main_loader_is_active: false,
    configs: [],
    user_name: "",
    url: "",
    total_count: 0,
    desktop: {},
    mobile: {},
    preferences: {},
    differ_time: {},
    resolution: {},
    chunkType: "multi",
    layout: "portrait",
    email: true,
    defer_time: 2,
    compressed: false,
    win_res: "RES100021498719908608",
    mac_res: "RES100021498719908608",
  },
  created() {
    chrome.storage.sync.get(["is_verified", "lt_user_name"], (items) => {
      if (!chrome.runtime.error) {
        if (!items.is_verified) {
          window.location.href = chrome.runtime.getURL("welcome.html");
        }
        if (items.lt_user_name) {
          this.user_name = items.lt_user_name;
        }
      }
    });
    this.sGetPagesUrl();
    this.getDesktop();
    this.getMobile();
    this.getPreferences();
    this.getDifferTime();
    this.getResolution();
  },
  methods: {
    getDesktop: function () {
      axios
        .get(`../assets/launchers/screenshot-desktop.json`)
        .then(
          function (response) {
            this.desktop = response.data;
          }.bind(this)
        )
        .catch(function (_) {}.bind(this));
    },
    getMobile: function () {
      axios
        .get(`../assets/launchers/screenshot-mobile.json`)
        .then(
          function (response) {
            this.mobile = response.data;
          }.bind(this)
        )
        .catch(function (_) {}.bind(this));
    },
    getPreferences: function () {
      axios
        .get(`../assets/sample-json/preferences.json`)
        .then(
          function (response) {
            this.preferences = response.data;
            this.win_res_list = this.preferences.win_res;
          }.bind(this)
        )
        .catch(function (_) {}.bind(this));
    },
    getResolution: function () {
      axios
        .get(`../assets/sample-json/resolution.json`)
        .then(
          function (response) {
            this.resolution = response.data;
          }.bind(this)
        )
        .catch(function (_) {}.bind(this));
    },
    getDifferTime: function () {
      axios
        .get(`../assets/sample-json/screenshot-preferences.json`)
        .then(
          function (response) {
            this.differ_time = response.data;
          }.bind(this)
        )
        .catch(function (_) {}.bind(this));
    },
    getImgUrl: function (base, browser, color, type) {
      let images = base + browser + (color ? color + type : type);
      return images;
    },
    getTabRef: function (hash, name) {
      return hash ? hash + name : name;
    },
    setDesktopConf: function (
      os_version_id,
      browser_id,
      browser_version_id,
      code,
      name,
      resolution_id
    ) {
      let deviceIndex = this.configs.findIndex((device) => {
        return (
          device.type === "desktop" &&
          device.os_version_id === os_version_id &&
          device.browser_id === browser_id &&
          device.browser_version_id === browser_version_id &&
          device.os === name &&
          device.resolution_id === resolution_id &&
          device.code === code
        );
      });
      if (deviceIndex > -1) {
        this.configs.splice(deviceIndex, 1);
        $(`#${browser_id}_${os_version_id}_${browser_version_id}`).removeClass(
          "active myCustomActive"
        );
      } else {
        if (this.configs.length >= 25) {
          alert(
            "You Selection going to exceeded maximum limit. Please unselect one then Select"
          );
        } else {
          this.configs.push({
            type: "desktop",
            os_version_id: os_version_id,
            browser_id: browser_id,
            browser_version_id: browser_version_id,
            resolution_id: resolution_id,
            os: name,
            code: code,
          });
          $(`#${browser_id}_${os_version_id}_${browser_version_id}`).addClass(
            "active myCustomActive"
          );
        }
      }

      this.getBrowserCount();
      this.isDesktopActive();
    },
    setMobileConf: function (
      type,
      manufacturer_id,
      device_id,
      os_version_id,
      resolution_id
    ) {
      let deviceIndex = this.configs.findIndex((device) => {
        return (
          device.type === type &&
          manufacturer_id === manufacturer_id &&
          device.device_id === device_id &&
          device.os_version_id === os_version_id &&
          device.resolution_id === resolution_id
        );
      });
      if (deviceIndex > -1) {
        this.configs.splice(deviceIndex, 1);
        $(
          `#${manufacturer_id}_${device_id}_${os_version_id}_${resolution_id}`
        ).removeClass("active myCustomActive");
      } else {
        if (this.configs.length >= 25) {
          alert(
            "You Selection going to exceeded maximum limit. Please unselect one then Select"
          );
        } else {
          this.configs.push({
            type: type,
            manufacturer_id: manufacturer_id,
            device_id: device_id,
            os_version_id: os_version_id,
            resolution_id: resolution_id,
          });
          $(
            `#${manufacturer_id}_${device_id}_${os_version_id}_${resolution_id}`
          ).addClass("active myCustomActive");
        }
      }
      this.getBrowserCount();
      this.isMobileActive();
    },
    isDesktopActive: function () {
      this.desktop.browsers.forEach((browser) => {
        this.desktop.desktop.forEach((element) => {
          let deviceIndex = this.configs.findIndex((device) => {
            return (
              device.type === "desktop" &&
              device.browser_id === browser.browser_id &&
              device.os_version_id === element.os_version_id
            );
          });
          if (deviceIndex > -1) {
            $(`#${browser.browser_id}_${element.os_version_id}`).addClass(
              "active myCustomActive"
            );
          } else {
            $(`#${browser.browser_id}_${element.os_version_id}`).removeClass(
              "active myCustomActive"
            );
          }
        });
      });
    },
    isMobileActive: function () {
      let androidConf = this.configs.filter(function (el) {
        return el.type === "android";
      });

      let iosConf = this.configs.filter(function (el) {
        return el.type === "ios";
      });
      this.mobile.android.forEach((mob_element) => {
        let deviceIndex = androidConf.findIndex((device) => {
          return device.manufacturer_id === mob_element.manufacturer_id;
        });
        if (deviceIndex > -1) {
          $(`#${mob_element.manufacturer_id}`).addClass(
            "active myCustomActive"
          );
        } else {
          $(`#${mob_element.manufacturer_id}`).removeClass(
            "active myCustomActive"
          );
        }
      });

      this.mobile.ios.forEach((mob_element) => {
        let deviceIndex = iosConf.findIndex((device) => {
          return device.os_version_id === mob_element.os_version_id;
        });
        if (deviceIndex > -1) {
          $(`#${mob_element.os_version_id}`).addClass("active myCustomActive");
        } else {
          $(`#${mob_element.os_version_id}`).removeClass(
            "active myCustomActive"
          );
        }
      });
    },
    getBrowserCount: function () {
      this.desktop.browsers.forEach((element) => {
        $(`#${element.browser_id}`).text(
          this.configs.filter(function (value) {
            return value.browser_id === element.browser_id;
          }).length
        );
      });
      this.total_count = this.configs.length;
    },
    clearConfig: function () {
      this.configs = [];
      this.getBrowserCount();
      $(`.myCustomActive`).removeClass("active");
    },
    postScreenShot: function () {
      if (this.configs.length <= 0) {
        alert(`Please select atleast one device`);
      } else {
        if (!this.myDefaultConf.url.startsWith("http")) {
          this.myDefaultConf.url = "http://" + this.myDefaultConf.url;
        }
        if (this.myDefaultConf.url) {
          this.myDefaultConf.url = this.myDefaultConf.url.trim().toLowerCase();
        }
        if (this.isUrlValid(this.myDefaultConf.url)) {
          this.main_loader_is_active = true;
          chrome.storage.sync.get(
            ["lt_scr_access_token", "lt_scr_organization_id"],
            (items) => {
              if (!chrome.runtime.error) {
                if (items.lt_scr_access_token && items.lt_scr_organization_id) {
                  this.sendScreenshot(
                    items.lt_scr_organization_id,
                    items.lt_scr_access_token
                  );
                } else {
                  this.main_loader_is_active = true;
                  chrome.storage.sync.set(
                    {
                      myDefaultConf: JSON.stringify(this.myDefaultConf),
                    },
                    () => {
                      alert(
                        `Please activate LambdaTest Screenshot plugin by entering Access Token. Click Here to know how`
                      );
                      chrome.tabs.create({
                        url: `${chrome.runtime.getURL("welcome.html")}`,
                      });
                    }
                  );
                }
              } else {
                this.main_loader_is_active = true;
              }
            }
          );
        } else {
          alert("Please enter valid URL");
        }
      }
    },
    sendScreenshot: function (org_id, lt_scr_access_token) {
      if (org_id != null) {
        this.myDefaultConf.org_id = org_id;
        this.configs.forEach((element) => {
          if (!element.device_id) {
            element.width = this.resolution[this.myDefaultConf.win_res].width;
            element.height = this.resolution[this.myDefaultConf.win_res].height;
          }
          delete element.manufacturer_id;
        });
        axios
          .post(`${lt_falcon_url}/tests`, this.myDefaultConf, {
            headers: {
              "Content-type": "application/json",
              accessToken: lt_scr_access_token,
              username: this.user_name,
            },
          })
          .then(
            function (response) {
              let test_id = response.data.test_id;
              if (test_id) {
                this.main_loader_is_active = false;
                chrome.tabs.create({
                  url: `${chrome.runtime.getURL(
                    "thumbnail.html"
                  )}?test_id=${test_id}&url=${this.myDefaultConf.url}`,
                });
              }
              if (response.data.type) {
                alert(response.data.message);
              }
            }.bind(this)
          )
          .catch(
            function (error) {
              this.main_loader_is_active = false;
              chrome.storage.sync.set(
                {
                  myDefaultConf: JSON.stringify(this.myDefaultConf),
                },
                () => {
                  if (error.response && error.response.status === 401) {
                    alert(
                      `Please activate LambdaTest Screenshot plugin by entering Access Token. Click Here to know how`
                    );
                  } else if (error.response && error.response.status === 402) {
                    alert(
                      "Uh Ohhhh....!!! Looks like you have exhausted your free screenshot sessions for this month. Upgrade your plan to get Unlimited Screenshots"
                    );
                  } else {
                    alert("Please contact to support");
                  }
                  chrome.tabs.create({
                    url: `${chrome.runtime.getURL("welcome.html")}`,
                  });
                }
              );
            }.bind(this)
          );
      } else {
        this.main_loader_is_active = false;
        alert("Please contact to support");
        chrome.tabs.create({
          url: `${chrome.runtime.getURL("welcome.html")}`,
        });
      }
    },
    isUrlValid: function (userInput) {
      const regexp = /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/;
      const regexp1 = /(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}/;
      if (regexp.test(userInput)) {
        return true;
      } else if (regexp1.test(userInput)) {
        return true;
      } else if (userInput.indexOf("localhost") >= 0) {
        return true;
      } else {
        return false;
      }
    },
    showMore: function (ele) {
      if ($(`#more_less_${ele}`).text().includes("more")) {
        $(`.${ele}`).removeClass("display_none");
        $(`#more_less_${ele}`).text("less..");
      } else {
        $(`.${ele}`).addClass("display_none");
        $(`#more_less_${ele}`).text("more..");
      }
    },
    updateUrl: function () {
      chrome.tabs.getSelected(null, (tab) => {
        this.url = tab.url;
        if (
          tab.url.indexOf(`https://accounts.lambdatest.com`) > -1 ||
          tab.url.indexOf(`https://app.lambdatest.com`) > -1 ||
          tab.url.indexOf(`chrome-extension://`) > -1
        ) {
          this.url = "";
        }
      });
    },
    sGetPagesUrl: function () {
      this.sPagesUrl = {
        setting: chrome.runtime.getURL("welcome.html"),
        test_log: chrome.runtime.getURL("test_log.html"),
        screenshot: chrome.runtime.getURL("screenshot.html"),
      };
    },
    sHrefChange: function (_location) {
      window.location.href = _location;
    },
    getUserName: function () {
      chrome.storage.sync.get(["lt_user_name"], (items) => {
        if (!chrome.runtime.error) {
          return items.lt_user_name;
        }
      });
    },
    logout: function () {
      chrome.storage.sync.remove([
        "email",
        "token",
        "lt_user_name",
        "lt_scr_access_token",
        "lt_scr_organization_id",
        "is_verified",
        "myDefaultConf",
      ]);
      window.location.href = chrome.runtime.getURL("welcome.html");
    },
  },
  computed: {
    myDefaultConf() {
      return {
        configs: this.configs,
        test_type_id: "Screenshot",
        layout: this.layout,
        defer_time: this.defer_time,
        chunkType: this.chunkType,
        url: this.url,
        email: this.email,
        compressed: this.compressed,
        win_res: this.win_res,
        mac_res: this.mac_res,
        org_id: "",
        client: "ChromeExt",
      };
    },
  },
});
